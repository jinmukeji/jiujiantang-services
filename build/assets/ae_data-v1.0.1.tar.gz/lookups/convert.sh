#!/usr/bin/env bash
set -e

CUR=`dirname $0`

# ./convert.sh lookup-b.yaml
KEYS=($(yq --raw-output '.items[].key | rtrimstr(".0")' $1))
CONTENTS=($(yq --raw-output '.items[].content' $1))

OUT=${CUR}/out

LEN=${#KEYS[@]}
for (( i=1; i<${LEN}+1; i++ ));
do
  echo ${CONTENTS[$i-1]} | tr -d '\r' | tr -d '\n' > $OUT/${KEYS[$i-1]}.en.jet
  echo ${CONTENTS[$i-1]} | tr -d '\r' | tr -d '\n' > $OUT/${KEYS[$i-1]}.zh-Hans.jet
  echo ${CONTENTS[$i-1]} | tr -d '\r' | tr -d '\n' | opencc -c ${CUR}/s2t.json > $OUT/${KEYS[$i-1]}.zh-Hant.jet
done

